### 代码结构

#### SCL_decoder: 

主要包含SCL译码过程，用于在强化学习过程中生成奖励值。

生成奖励的函数为get_reward，将使用python接口在强化学习过程中调用。

#### RL

包含强化学习算法的实现，环境的搭建，训练以及测试代码。

##### algoRL

强化学习算法的实现。包含DQN, q-learning。

##### env

论文中的Game环境搭建，使用gym库进行搭建。

##### 训练与测试

使用train.py进行训练，使用test.py进行测试。