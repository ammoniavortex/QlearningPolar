from env.ConstructionGame import ConstructionGameEnv
from algoRL.DQN import DQN, MEMORY_CAPACITY
import matplotlib.pyplot as plt
import copy
import gym
import os
from tqdm import tqdm
import torch
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

env = ConstructionGameEnv(8, 4)
# env = gym.make('CartPole-v0')

NUM_ACTIONS = env.action_space.n
NUM_STATES = env.observation_space.shape[0]
ENV_A_SHAPE = 0 if isinstance(env.action_space.sample(), int) else env.action_space.sample.shape
print(NUM_STATES, NUM_ACTIONS, ENV_A_SHAPE)

# dqn = DQN(NUM_STATES, NUM_ACTIONS, ENV_A_SHAPE)
dqn = torch.load('dqn-8-4.pt')
episodes = 40000
print("Collecting Experience....")
reward_list = []
# plt.ion()
# fig, ax = plt.subplots()


log_step = 1000
t = 0
r = 0
for i in range(episodes):
    t += 1
    state = env.reset()
    ep_reward = 0
    while True:
        # env.render()
        action = dqn.choose_action(state)
        action = int(action)
        next_state, reward, done, _ = env.step(action)

        dqn.store_transition(state, action, reward, next_state)
        ep_reward += reward
        # print(state, action, reward, done, next_state)
        if dqn.memory_counter >= MEMORY_CAPACITY:
            dqn.learn()
            # if done:
            #     print("episode: {} , the episode reward is {}".format(i, round(ep_reward, 3)))
        if done:
            break
        state = next_state
    r += ep_reward
    if t % log_step == 0:
        print(f'Avg reward {r/log_step}')
        r = 0
        torch.save(dqn, 'dqn.pt')
    # r = copy.copy(ep_reward)
    # reward_list.append(r)
    # ax.set_xlim(0, 400)
    # # ax.set_ylim(90, 140)
    # # ax.cla()
    # ax.plot(reward_list, 'g-', label='Reward against episodes')
    # plt.pause(0.001)
