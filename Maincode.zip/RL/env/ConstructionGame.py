import random

import gym
from gym import spaces
import numpy as np
import matlab.engine
import matlab


class ConstructionGameEnv(gym.Env):

    def __init__(self, N, K):
        self.N = N
        self.K = K
        self.action_space = spaces.Discrete(2)
        self.observation_space = spaces.Box(0, np.inf, shape=(2,))
        self.state = None
        self.terminal = np.array([K, N - K])
        self.frozen_bit_flag = matlab.double([0 for _ in range(N)])
        self.step_i = 0

        self.eng = matlab.engine.start_matlab()
        self.eng.addpath('D:\learning\matlab\SCL_decoder')

    def step(self, action):
        assert self.action_space.contains(action), "%r (%s) invalid" % (action, type(action))
        x, y = self.state
        valid_step = True

        # if action == 0:
        #     self.state = [x, min(self.terminal[1], y + 1)]
        # else:
        #     self.state = [min(self.terminal[0], x + 1), y]
        if action == 0:
            if y + 1 > self.terminal[1]:
                action = 1
                self.state = [x + 1, y]
            else:
                self.state = [x, y + 1]
        else:
            if x + 1 > self.terminal[0]:
                action = 0
                self.state = [x, y + 1]
            else:
                self.state = [x + 1, y]

        self.step_i += 1
        res = self.eng.get_reward(action, self.step_i, self.frozen_bit_flag)
        self.frozen_bit_flag = matlab.double(res[0][2:2 + self.N])
        reward = res[0][0]
        done = res[0][1]
        return self.state, reward, done, {}

    def reset(self):
        self.state = [0, 0]
        self.frozen_bit_flag = matlab.double([0 for _ in range(self.N)])
        self.step_i = 0
        return self.state

    def render(self, mode='human'):
        return None

    def close(self):
        return None


if __name__ == '__main__':
    env = ConstructionGameEnv(8, 4)
    state = env.reset()
    # actions = [int(i) for i in list('0000000011111111')]
    # actions = [1, 1, 1, 1, 0, 0, 0, 0]
    # actions = [0, 0, 0, 0, 1, 1, 1, 1]
    actions = [int(i) for i in list('01010101')]
    t = 0
    for j in range(100):
        state = env.reset()
        # actions = [random.randint(0, 1) for i in range(8)]
        for i in range(10000):
            action = actions[i]
            state, r, done, _ = env.step(int(action))
            if r == -1:
                t += 1
            if done:
                break
            # print(state, r, done)
    print(t)
