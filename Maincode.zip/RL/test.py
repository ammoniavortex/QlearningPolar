import numpy as np
import torch
from env.ConstructionGame import ConstructionGameEnv
import os
from tqdm import tqdm
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

env = ConstructionGameEnv(8, 4)
dqn = torch.load('dqn-8-4.pt')

state = env.reset()
ep_reward = 0

r = 0
for j in range(100):
    state = env.reset()
    ep_reward = 0
    actions = [0 for k in range(8)]
    for i in range(8):
        action = dqn.choose_action_opt(state)
        actions[i] = action
        action = int(action)
        next_state, reward, done, _ = env.step(action)
        ep_reward += reward
        # print(state, action, reward, next_state, done)
        if done:
            break
        state = next_state
    r += ep_reward
    print(actions, ep_reward)
print(r)

