# -*- coding: utf-8 -*-
import random
import numpy as np
from env.ConstructionGame import ConstructionGameEnv


class QLearningAgent:
    def __init__(self, actions):
        # actions = [0, 1, 2, 3]
        self.actions = actions
        self.learning_rate = 0.01
        self.discount_factor = 1
        self.epsilon = 0.1
        self.q_table = np.zeros((5, 5, 2))

    # 采样 <s, a, r, s'>
    def learn(self, state, action, reward, next_state):
        current_q = self.q_table[state[0]][state[1]][action]
        # 贝尔曼方程更新
        new_q = reward + self.discount_factor * max(self.q_table[next_state[0]][next_state[1]])
        self.q_table[state[0]][state[1]][action] += self.learning_rate * (new_q - current_q)

    # 从Q-table中选取动作
    def get_action(self, state):
        if np.random.rand() < self.epsilon:
            # 贪婪策略随机探索动作
            action = np.random.choice(self.actions)
        else:
            # 从q表中选择
            state_action = self.q_table[state[0]][state[1]]
            action = self.arg_max(state_action)
        return action

    def get_action_opt(self, state):
        state_action = self.q_table[state[0]][state[1]]
        action = self.arg_max(state_action)
        return action

    @staticmethod
    def arg_max(state_action):
        max_index_list = []
        max_value = state_action[0]
        for index, value in enumerate(state_action):
            if value > max_value:
                max_index_list.clear()
                max_value = value
                max_index_list.append(index)
            elif value == max_value:
                max_index_list.append(index)
        return random.choice(max_index_list)


if __name__ == "__main__":
    env = ConstructionGameEnv(8, 4)
    agent = QLearningAgent(actions=list(range(env.action_space.n)))
    for episode in range(1000):
        state = env.reset()
        while True:
            # agent产生动作
            action = agent.get_action(state)
            next_state, reward, done, _ = env.step(int(action))
            # 更新Q表
            agent.learn(state, action, reward, next_state)
            state = next_state
            # 当到达终点就终止游戏开始新一轮训练
            if done:
                break
    state = env.reset()
    actions = []
    for i in range(8):
        action = agent.get_action(state)
        next_state, reward, done, _ = env.step(int(action))
        # 更新Q表
        state = next_state
        # 当到达终点就终止游戏开始新一轮训练
        actions.append(action)

        if done:
            break
    print(actions)
