frozen_bit_flag = zeros(1, 8);
for step=1:8
    a=input('Action: ');
    res = get_reward(a,step,frozen_bit_flag);
    disp(res);
    frozen_bit_flag = res(3:10);
end